# RECESS IMS 백엔드 API 개발 명세서

## 📌 문서 목적
프론트엔드는 **완료**되었습니다. 이 문서는 백엔드 개발자가 API만 붙이면 되는 수준으로 정리한 명세서입니다.

**예상 개발 기간: 프론트 1명 + 백엔드 1명 = 3~4주 (MVP)**

---

## 1. 시스템 구조

```
┌─────────────────────────────────────────────────────────────┐
│                    RECESS IMS Architecture                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐   │
│   │   프론트엔드   │    │   백엔드     │    │  데이터베이스  │   │
│   │   (완료 ✅)   │───▶│  (개발 필요)  │───▶│   (설계 필요)  │   │
│   │             │    │             │    │             │   │
│   │  HTML/CSS   │    │  Express.js │    │ PostgreSQL  │   │
│   │  JavaScript │    │  or FastAPI │    │  or MySQL   │   │
│   │  102 pages  │    │             │    │             │   │
│   └─────────────┘    └─────────────┘    └─────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. 핵심 기능 (MVP)

### 2.1 발주서 관리 (Purchase Order)

#### 데이터 모델
```sql
CREATE TABLE purchase_orders (
    id              SERIAL PRIMARY KEY,
    order_no        VARCHAR(20) UNIQUE NOT NULL,  -- PO-2026-0001
    project_id      INTEGER REFERENCES projects(id),
    episode_id      INTEGER REFERENCES episodes(id),
    process_type    VARCHAR(20) NOT NULL,         -- layout, genga, douga, color, bg, composite
    vendor_id       INTEGER REFERENCES vendors(id),
    vendor_type     VARCHAR(20) NOT NULL,         -- company, freelancer
    
    -- 금액
    quantity        INTEGER NOT NULL,
    unit            VARCHAR(10) NOT NULL,         -- cut, sheet
    unit_price      DECIMAL(10,2) NOT NULL,
    base_amount     DECIMAL(12,2) NOT NULL,
    
    -- 보정률
    difficulty_rate DECIMAL(5,2) DEFAULT 1.00,
    urgent_rate     DECIMAL(5,2) DEFAULT 1.00,
    
    -- 세금
    vat_amount      DECIMAL(12,2),
    withholding_tax DECIMAL(12,2),                -- 원천징수 (프리랜서만)
    
    -- 최종 금액
    total_amount    DECIMAL(12,2) NOT NULL,
    net_amount      DECIMAL(12,2) NOT NULL,       -- 실지급액
    
    -- 상태
    status          VARCHAR(20) DEFAULT 'draft',  -- draft, pending, approved, in_progress, completed, settled
    
    -- 날짜
    deadline        DATE,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW(),
    settled_at      TIMESTAMP,
    
    -- 메타
    created_by      INTEGER REFERENCES users(id),
    memo            TEXT
);
```

#### API 엔드포인트
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | `/api/orders` | 발주서 목록 조회 |
| GET | `/api/orders/:id` | 발주서 상세 조회 |
| POST | `/api/orders` | 발주서 생성 |
| PUT | `/api/orders/:id` | 발주서 수정 |
| DELETE | `/api/orders/:id` | 발주서 삭제 |
| POST | `/api/orders/:id/approve` | 발주서 승인 |
| POST | `/api/orders/:id/settle` | 정산 처리 |

#### 발주서 생성 요청 예시
```json
POST /api/orders
{
    "project_id": 1,
    "episode_id": 12,
    "process_type": "genga",
    "vendor_id": 5,
    "vendor_type": "freelancer",
    "quantity": 50,
    "unit": "cut",
    "unit_price": 15000,
    "difficulty_rate": 1.0,
    "urgent_rate": 1.0,
    "deadline": "2026-02-20",
    "memo": "EP12 원화 작업"
}
```

#### 발주서 응답 예시
```json
{
    "id": 24,
    "order_no": "PO-2026-0024",
    "project": {
        "id": 1,
        "name": "주술회전 2기"
    },
    "episode": {
        "id": 12,
        "name": "EP12"
    },
    "process_type": "genga",
    "process_name": "원화",
    "vendor": {
        "id": 5,
        "name": "김○○",
        "type": "freelancer"
    },
    "quantity": 50,
    "unit": "cut",
    "unit_price": 15000,
    "base_amount": 750000,
    "difficulty_rate": 1.0,
    "urgent_rate": 1.0,
    "vat_amount": 75000,
    "withholding_tax": 24750,
    "total_amount": 825000,
    "net_amount": 800250,
    "status": "pending",
    "deadline": "2026-02-20",
    "created_at": "2026-01-28T09:00:00Z"
}
```

---

### 2.2 정산 관리 (Settlement)

#### 데이터 모델
```sql
CREATE TABLE settlements (
    id              SERIAL PRIMARY KEY,
    settlement_no   VARCHAR(20) UNIQUE NOT NULL,  -- STL-2026-0001
    order_id        INTEGER REFERENCES purchase_orders(id),
    vendor_id       INTEGER REFERENCES vendors(id),
    
    -- 금액
    order_amount    DECIMAL(12,2) NOT NULL,       -- 발주 금액
    vat_amount      DECIMAL(12,2),
    withholding_tax DECIMAL(12,2),                -- 원천징수
    net_amount      DECIMAL(12,2) NOT NULL,       -- 실지급액
    
    -- 지급 정보
    bank_account    VARCHAR(50),
    payment_date    DATE,
    
    -- 상태
    status          VARCHAR(20) DEFAULT 'pending', -- pending, processing, completed, cancelled
    
    -- 날짜
    created_at      TIMESTAMP DEFAULT NOW(),
    completed_at    TIMESTAMP,
    
    -- 메타
    processed_by    INTEGER REFERENCES users(id),
    memo            TEXT
);
```

#### API 엔드포인트
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | `/api/settlements` | 정산 목록 조회 |
| GET | `/api/settlements/:id` | 정산 상세 조회 |
| POST | `/api/settlements` | 정산 생성 (발주서 기반) |
| PUT | `/api/settlements/:id` | 정산 수정 |
| POST | `/api/settlements/:id/complete` | 정산 완료 처리 |
| GET | `/api/settlements/summary` | 정산 요약 (대시보드용) |

#### 정산 요약 응답 예시
```json
GET /api/settlements/summary?month=2026-01
{
    "period": "2026-01",
    "total_amount": 47250000,
    "completed_amount": 34450000,
    "pending_amount": 12800000,
    "total_withholding_tax": 1136850,
    "total_net_amount": 33313150,
    "completed_count": 16,
    "pending_count": 8,
    "settlement_rate": 73.0,
    "by_process": {
        "genga": 18500000,
        "douga": 12300000,
        "color": 9800000,
        "bg": 4200000,
        "composite": 2450000
    },
    "by_project": [
        { "project_id": 1, "name": "주술회전 2기", "amount": 21500000 },
        { "project_id": 2, "name": "진격의 거인", "amount": 15800000 },
        { "project_id": 3, "name": "SPY×FAMILY", "amount": 9950000 }
    ]
}
```

---

### 2.3 원천징수 계산 로직

```javascript
/**
 * 원천징수 계산 (프리랜서 전용)
 * - 소득세: 3%
 * - 지방소득세: 0.3%
 * - 합계: 3.3%
 */
function calculateWithholdingTax(amount, vendorType) {
    if (vendorType !== 'freelancer') {
        return 0;
    }
    
    const incomeTax = Math.floor(amount * 0.03);      // 소득세 3%
    const localTax = Math.floor(amount * 0.003);     // 지방소득세 0.3%
    
    return incomeTax + localTax;
}

/**
 * 부가가치세 계산
 */
function calculateVAT(amount) {
    return Math.floor(amount * 0.1);  // 10%
}

/**
 * 최종 금액 계산
 */
function calculateNetAmount(baseAmount, vendorType) {
    const vat = calculateVAT(baseAmount);
    const tax = calculateWithholdingTax(baseAmount, vendorType);
    
    return {
        base_amount: baseAmount,
        vat_amount: vat,
        withholding_tax: tax,
        total_amount: baseAmount + vat,
        net_amount: baseAmount + vat - tax
    };
}
```

---

## 3. 부수 기능 (MVP 포함)

### 3.1 프로젝트 관리
```
GET    /api/projects
GET    /api/projects/:id
GET    /api/projects/:id/episodes
GET    /api/projects/:id/statistics
```

### 3.2 에피소드 관리
```
GET    /api/episodes/:id
GET    /api/episodes/:id/cuts
GET    /api/episodes/:id/orders
```

### 3.3 작업자(수주사) 관리
```
GET    /api/vendors
GET    /api/vendors/:id
GET    /api/vendors/:id/orders
GET    /api/vendors/:id/settlements
POST   /api/vendors
PUT    /api/vendors/:id
```

### 3.4 사용자 인증
```
POST   /api/auth/login
POST   /api/auth/logout
GET    /api/auth/me
POST   /api/auth/refresh
```

---

## 4. 데이터베이스 스키마 (전체)

```sql
-- 사용자
CREATE TABLE users (
    id          SERIAL PRIMARY KEY,
    email       VARCHAR(100) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,
    name        VARCHAR(50) NOT NULL,
    role        VARCHAR(20) NOT NULL,  -- admin, pm, pd, team_lead, worker
    tier        INTEGER DEFAULT 1,     -- 0: 제작위원회, 1: 원청, 2: 하청
    created_at  TIMESTAMP DEFAULT NOW()
);

-- 프로젝트
CREATE TABLE projects (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    client      VARCHAR(100),
    status      VARCHAR(20) DEFAULT 'active',
    start_date  DATE,
    end_date    DATE,
    budget      DECIMAL(15,2),
    created_at  TIMESTAMP DEFAULT NOW()
);

-- 에피소드
CREATE TABLE episodes (
    id          SERIAL PRIMARY KEY,
    project_id  INTEGER REFERENCES projects(id),
    name        VARCHAR(50) NOT NULL,
    episode_no  INTEGER,
    cut_count   INTEGER DEFAULT 0,
    status      VARCHAR(20) DEFAULT 'pre_production',
    deadline    DATE,
    created_at  TIMESTAMP DEFAULT NOW()
);

-- 수주사/작업자
CREATE TABLE vendors (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    type            VARCHAR(20) NOT NULL,  -- company, freelancer
    country         VARCHAR(10) DEFAULT 'KR',
    tax_id          VARCHAR(50),           -- 사업자번호/주민번호
    bank_name       VARCHAR(50),
    bank_account    VARCHAR(50),
    default_rate    DECIMAL(10,2),         -- 기본 단가
    contact_email   VARCHAR(100),
    contact_phone   VARCHAR(20),
    created_at      TIMESTAMP DEFAULT NOW()
);

-- 발주서 (위에서 정의)
-- 정산 (위에서 정의)

-- 발주 항목 (상세)
CREATE TABLE order_items (
    id          SERIAL PRIMARY KEY,
    order_id    INTEGER REFERENCES purchase_orders(id),
    cut_range   VARCHAR(50),       -- C001-C010
    quantity    INTEGER NOT NULL,
    description TEXT,
    difficulty  DECIMAL(3,2) DEFAULT 1.0,
    subtotal    DECIMAL(12,2)
);
```

---

## 5. 개발 우선순위

### Phase 1: MVP (3~4주)
1. ✅ 프론트엔드 - 완료
2. 🔲 DB 설계 및 마이그레이션 (3일)
3. 🔲 인증 API (3일)
4. 🔲 **발주서 CRUD API** (5일) ⬅️ 핵심
5. 🔲 **정산 API** (3일) ⬅️ 핵심
6. 🔲 프론트엔드 API 연동 (3일)

### Phase 2: 안정화 (2~3주)
7. 🔲 파일 업로드
8. 🔲 알림 시스템
9. 🔲 리포트/엑셀 다운로드
10. 🔲 권한 관리 상세화

### Phase 3: 고도화 (추후)
11. 🔲 블록체인 연동
12. 🔲 NFT 민팅
13. 🔲 스마트 컨트랙트

---

## 6. 기술 스택 권장

| 영역 | 권장 기술 | 비고 |
|------|-----------|------|
| Backend | **Node.js + Express** or **Python + FastAPI** | 둘 다 가능 |
| Database | **PostgreSQL** | JSON 지원, 안정성 |
| ORM | Prisma (Node) or SQLAlchemy (Python) | |
| Auth | JWT + Refresh Token | |
| File Storage | AWS S3 or MinIO | |
| Cache | Redis | 선택사항 |

---

## 7. 현재 프론트엔드 현황

### 완료된 페이지 (발주/정산 관련)
| 페이지 | 경로 | 설명 |
|--------|------|------|
| 발주서 생성 | `/pages/accounting/order-create-v2.html` | 4단계 위자드 |
| 발주서 관리 | `/pages/accounting/purchase-order.html` | 목록/필터/검색 |
| 정산 처리 | `/pages/settlement/settlement-process.html` | 일괄/개별 정산 |
| 정산 대시보드 | `/pages/settlement/settlement-dashboard.html` | KPI/차트 |

### API 연동 포인트 (프론트엔드)
```javascript
// 프론트엔드에서 호출하는 API (현재 Mock)
// 이 부분만 실제 API로 교체하면 됨

// 발주서 목록
fetch('/api/orders?status=pending&month=2026-01')

// 발주서 생성
fetch('/api/orders', {
    method: 'POST',
    body: JSON.stringify(orderData)
})

// 정산 처리
fetch('/api/settlements', {
    method: 'POST',
    body: JSON.stringify({ order_ids: [1, 2, 3] })
})

// 대시보드 데이터
fetch('/api/settlements/summary?month=2026-01')
```

---

## 8. 결론

### 이미 완료된 것
- ✅ 프론트엔드 UI/UX (102 페이지)
- ✅ 발주서 생성 플로우
- ✅ 정산 처리 화면
- ✅ 대시보드
- ✅ 원천징수 계산 로직

### 백엔드가 해야 할 것
1. **DB 테이블 생성** (위 스키마 참조)
2. **REST API 개발** (CRUD + 정산 로직)
3. **프론트와 연동**

### 예상 일정
| 작업 | 기간 |
|------|------|
| DB 설계 + 마이그레이션 | 3일 |
| 인증 API | 3일 |
| 발주서 API | 5일 |
| 정산 API | 3일 |
| 프론트 연동 + 테스트 | 3일 |
| **합계** | **~3주** |

---

**문서 작성일:** 2026-02-06  
**버전:** 1.0  
**작성자:** RECESS IMS 기획팀
