/**
 * RECESS IMS - TUSUploader v1.0
 * TUS 프로토콜 기반 대용량 파일 업로드 (시뮬레이션)
 */
(function(window) {
    'use strict';

    class TUSUploader {
        constructor(options = {}) {
            this.endpoint = options.endpoint || '/api/upload';
            this.chunkSize = options.chunkSize || 5 * 1024 * 1024; // 5MB
            this.onProgress = options.onProgress || function() {};
            this.onComplete = options.onComplete || function() {};
            this.onError = options.onError || function() {};
            this._uploads = new Map();
        }

        upload(file) {
            const uploadId = `upload-${Date.now()}-${Math.random().toString(36).substr(2,5)}`;
            const totalChunks = Math.ceil(file.size / this.chunkSize);
            
            this._uploads.set(uploadId, {
                file,
                status: 'uploading',
                progress: 0,
                totalChunks,
                currentChunk: 0
            });

            // 업로드 시뮬레이션
            this._simulateUpload(uploadId, file);
            return uploadId;
        }

        _simulateUpload(uploadId, file) {
            const upload = this._uploads.get(uploadId);
            if (!upload) return;

            const interval = setInterval(() => {
                upload.currentChunk++;
                upload.progress = Math.min(100, Math.round((upload.currentChunk / upload.totalChunks) * 100));
                
                this.onProgress({
                    uploadId,
                    fileName: file.name,
                    progress: upload.progress,
                    loaded: Math.min(file.size, upload.currentChunk * this.chunkSize),
                    total: file.size
                });

                if (upload.progress >= 100) {
                    clearInterval(interval);
                    upload.status = 'complete';
                    this.onComplete({
                        uploadId,
                        fileName: file.name,
                        fileSize: file.size,
                        url: `/uploads/${uploadId}/${file.name}`
                    });
                }
            }, 200);
        }

        pause(uploadId) {
            const upload = this._uploads.get(uploadId);
            if (upload) upload.status = 'paused';
        }

        resume(uploadId) {
            const upload = this._uploads.get(uploadId);
            if (upload && upload.status === 'paused') {
                upload.status = 'uploading';
                this._simulateUpload(uploadId, upload.file);
            }
        }

        cancel(uploadId) {
            this._uploads.delete(uploadId);
        }

        getStatus(uploadId) {
            return this._uploads.get(uploadId) || null;
        }
    }

    window.TUSUploader = TUSUploader;
    console.log('[TUSUploader] 로드 완료 v1.0.0');
})(window);
