/**
 * RECESS IMS - LocalStorageManager v1.0
 * 로컬 데이터 관리 (라이브 페이지용)
 */
(function(window) {
    'use strict';

    const LocalStorageManager = {
        version: '1.0.0',

        get(key) {
            try {
                const data = localStorage.getItem(`recess_${key}`);
                return data ? JSON.parse(data) : null;
            } catch { return null; }
        },

        set(key, value) {
            try {
                localStorage.setItem(`recess_${key}`, JSON.stringify(value));
                return true;
            } catch { return false; }
        },

        remove(key) {
            localStorage.removeItem(`recess_${key}`);
        },

        getAll(prefix) {
            const results = {};
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith(`recess_${prefix || ''}`)) {
                    try {
                        results[key.replace('recess_', '')] = JSON.parse(localStorage.getItem(key));
                    } catch { results[key.replace('recess_', '')] = localStorage.getItem(key); }
                }
            }
            return results;
        },

        clear(prefix) {
            const keysToRemove = [];
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key.startsWith(`recess_${prefix || ''}`)) {
                    keysToRemove.push(key);
                }
            }
            keysToRemove.forEach(k => localStorage.removeItem(k));
        }
    };

    window.LocalStorageManager = LocalStorageManager;
    console.log('[LocalStorageManager] 로드 완료 v1.0.0');
})(window);
