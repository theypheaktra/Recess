/**
 * RECESS IMS - StorageManager v1.0
 * 파일 저장소 관리 (로컬 시뮬레이션)
 */
(function(window) {
    'use strict';

    const StorageManager = {
        version: '1.0.0',
        STORAGE_KEY: 'recess_file_storage',

        getUsage() {
            const data = localStorage.getItem(this.STORAGE_KEY);
            const size = data ? new Blob([data]).size : 0;
            return {
                used: size,
                total: 5 * 1024 * 1024 * 1024, // 5GB 시뮬레이션
                usedFormatted: this._formatSize(size),
                totalFormatted: '5.0 GB',
                percentage: (size / (5 * 1024 * 1024 * 1024) * 100).toFixed(2)
            };
        },

        getFiles(projectId) {
            try {
                const storage = JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '{}');
                return storage[projectId] || [];
            } catch { return []; }
        },

        addFile(projectId, fileInfo) {
            try {
                const storage = JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '{}');
                if (!storage[projectId]) storage[projectId] = [];
                storage[projectId].push({
                    ...fileInfo,
                    id: `FILE-${Date.now()}`,
                    uploadedAt: new Date().toISOString()
                });
                localStorage.setItem(this.STORAGE_KEY, JSON.stringify(storage));
                return true;
            } catch { return false; }
        },

        deleteFile(projectId, fileId) {
            try {
                const storage = JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '{}');
                if (storage[projectId]) {
                    storage[projectId] = storage[projectId].filter(f => f.id !== fileId);
                    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(storage));
                }
                return true;
            } catch { return false; }
        },

        _formatSize(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
    };

    window.StorageManager = StorageManager;
    console.log('[StorageManager] 로드 완료 v1.0.0');
})(window);
