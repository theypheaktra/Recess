/**
 * ============================================
 * RECESS IMS Auth Bundle v1.2
 * ============================================
 * 
 * 인증 관련 모든 기능을 하나로 통합
 * - AuthManager: 로그인/회원가입 처리
 * - SessionManager: 세션 관리
 * 
 * v1.2: WIX 사이드바 레이아웃 호환 (유저바 비활성화)
 * 
 * 사용법:
 * -------
 * <script src="./js/auth/auth-bundle.js"></script>
 * <!-- 자동으로 페이지 초기화 (인증 체크) -->
 */

(function(window) {
    'use strict';

    // ==========================================
    // SessionManager
    // ==========================================
    const SessionManager = {
        version: '1.2.0',

        STORAGE_KEYS: {
            SESSION: 'recess_session',
            USER: 'recess_current_user',
            USERS: 'recess_users',
            CODE_COUNTER: 'recess_code_counter'
        },

        TIER_DASHBOARDS: {
            0: 'index-tier0-committee.html',
            1: 'index-tier1-prime.html',
            2: 'index-tier2-sub.html'
        },

        setSession(userData) {
            const session = {
                userId: userData.id || userData.userId,
                recessCode: userData.recessCode,
                email: userData.email,
                userType: userData.userType,
                tier: userData.tier,
                role: userData.role,
                companyName: userData.companyName,
                displayName: userData.displayName || userData.companyName || userData.realName || userData.email,
                loginAt: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
            };

            localStorage.setItem(this.STORAGE_KEYS.SESSION, JSON.stringify(session));
            localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(userData));
            console.log(`[SessionManager] 세션 저장: ${session.email}`);
            return session;
        },

        getSession() {
            const s = localStorage.getItem(this.STORAGE_KEYS.SESSION);
            if (!s) return null;
            try {
                const session = JSON.parse(s);
                if (new Date(session.expiresAt) < new Date()) {
                    this.clearSession();
                    return null;
                }
                return session;
            } catch { return null; }
        },

        getCurrentUser() {
            const u = localStorage.getItem(this.STORAGE_KEYS.USER);
            return u ? JSON.parse(u) : null;
        },

        clearSession() {
            localStorage.removeItem(this.STORAGE_KEYS.SESSION);
            localStorage.removeItem(this.STORAGE_KEYS.USER);
        },

        isLoggedIn() {
            return this.getSession() !== null;
        },

        getBasePath() {
            const path = window.location.pathname;
            const depth = path.split('/').filter(p => p && !p.includes('.html')).length;
            return depth === 0 ? './' : '../'.repeat(depth);
        },

        getLoginPath() {
            return this.getBasePath() + 'login.html';
        },

        redirectToDashboard() {
            const session = this.getSession();
            if (!session) {
                window.location.href = this.getLoginPath();
                return;
            }
            const target = this.TIER_DASHBOARDS[session.tier] || 'index.html';
            window.location.href = this.getBasePath() + target;
        },

        // v1.2: WIX 사이드바 레이아웃에서는 유저바 비활성화
        // Tier 파일들이 자체 사이드바에 사용자 정보를 표시하므로 중복 방지
        injectUserBar() {
            // WIX 레이아웃 호환: 유저바 비활성화
            // 사이드바 기반 레이아웃에서는 사용자 정보가 사이드바에 표시됨
            return;
        },

        logout() {
            this.clearSession();
            window.location.href = this.getLoginPath();
        },

        initPage(options = {}) {
            const { requireAuth = true, showUserBar = false } = options;
            const path = window.location.pathname;
            
            // 로그인/회원가입 페이지 제외
            if (path.includes('login') || path.includes('signup')) return;

            // Tier 페이지 (사이드바 레이아웃) 제외 - 자체 init() 사용
            if (path.includes('index-tier')) return;

            // index.html (Tier 선택 페이지) 제외
            if (path.endsWith('index.html') || path.endsWith('/')) return;

            // iframe 내부 페이지 제외
            if (window.parent !== window) return;

            // 인증 체크 (독립 페이지에서만)
            if (requireAuth && !this.isLoggedIn()) {
                window.location.href = `${this.getLoginPath()}?redirect=${encodeURIComponent(path)}`;
                return;
            }
        }
    };

    // ==========================================
    // AuthManager
    // ==========================================
    const AuthManager = {
        version: '1.2.0',

        init() {
            if (!localStorage.getItem(SessionManager.STORAGE_KEYS.CODE_COUNTER)) {
                localStorage.setItem(SessionManager.STORAGE_KEYS.CODE_COUNTER, JSON.stringify({
                    CORP: 1000, BUSI: 2000, SOLE: 3000, FREE: 5000, COOP: 4000, COMM: 6000
                }));
            }
            if (!localStorage.getItem(SessionManager.STORAGE_KEYS.USERS)) {
                localStorage.setItem(SessionManager.STORAGE_KEYS.USERS, JSON.stringify([]));
            }
            this._createDemoUsers();
            console.log('[AuthManager] 초기화 완료');
            return this;
        },

        _createDemoUsers() {
            const users = JSON.parse(localStorage.getItem(SessionManager.STORAGE_KEYS.USERS));
            if (users.length > 0) return;

            const demos = [
                { email: 'chairman@committee.jp', password: 'demo1234', userType: 'COMM', tier: 0, role: 'L0-0', companyName: '나혼자솔로 제작위원회' },
                { email: 'secretary@aniplex.jp', password: 'demo1234', userType: 'CORP', tier: 0, role: 'L0-1', companyName: 'Aniplex Korea' },
                { email: 'cp@investor.jp', password: 'demo1234', userType: 'CORP', tier: 0, role: 'L0-3', companyName: 'TBS' },
                { email: 'pd@likaistudio.com', password: 'demo1234', userType: 'CORP', tier: 1, role: 'L1.1', companyName: 'LIKAI STUDIO' },
                { email: 'pm@likaistudio.com', password: 'demo1234', userType: 'CORP', tier: 1, role: 'L1.3', companyName: 'LIKAI STUDIO', realName: '이언호' },
                { email: 'pd@lizard.jp', password: 'demo1234', userType: 'CORP', tier: 2, role: 'L2.1', companyName: 'LIZARD STUDIO' },
                { email: 'animator@freelance.com', password: 'demo1234', userType: 'FREE', tier: 2, role: 'L2.5', realName: '김작가' }
            ];

            demos.forEach(d => {
                const code = this.generateRecessCode(d.userType);
                users.push({
                    id: `USR-${Date.now()}-${Math.random().toString(36).substr(2,5)}`,
                    recessCode: code,
                    email: d.email,
                    passwordHash: this._hashPassword(d.password),
                    userType: d.userType,
                    tier: d.tier,
                    role: d.role,
                    companyName: d.companyName || null,
                    realName: d.realName || null,
                    displayName: d.companyName || d.realName,
                    status: 'active',
                    createdAt: new Date().toISOString()
                });
            });

            localStorage.setItem(SessionManager.STORAGE_KEYS.USERS, JSON.stringify(users));
            console.log('[AuthManager] 데모 계정 생성 완료');
        },

        generateRecessCode(userType) {
            const counters = JSON.parse(localStorage.getItem(SessionManager.STORAGE_KEYS.CODE_COUNTER));
            const serial = counters[userType] || 1000;
            counters[userType] = serial + 1;
            localStorage.setItem(SessionManager.STORAGE_KEYS.CODE_COUNTER, JSON.stringify(counters));
            return `RC-${userType}-${String(serial).padStart(6, '0')}`;
        },

        _hashPassword(password) {
            let hash = 0;
            for (let i = 0; i < password.length; i++) {
                hash = ((hash << 5) - hash) + password.charCodeAt(i);
                hash = hash & hash;
            }
            return 'hash_' + Math.abs(hash).toString(16);
        },

        async login(email, password) {
            const users = JSON.parse(localStorage.getItem(SessionManager.STORAGE_KEYS.USERS));
            const user = users.find(u => u.email === email);

            if (!user) return { success: false, error: '등록되지 않은 이메일입니다.' };
            if (user.passwordHash !== this._hashPassword(password)) return { success: false, error: '비밀번호가 일치하지 않습니다.' };

            // SessionManager에 세션 저장
            SessionManager.setSession(user);

            return { success: true, user: user };
        },

        async register(data) {
            const { email, password, userType, tier, companyName, realName, displayName } = data;

            if (!email || !password) return { success: false, error: '이메일과 비밀번호는 필수입니다.' };

            const users = JSON.parse(localStorage.getItem(SessionManager.STORAGE_KEYS.USERS));
            if (users.find(u => u.email === email)) return { success: false, error: '이미 등록된 이메일입니다.' };

            const recessCode = this.generateRecessCode(userType || 'CORP');
            const newUser = {
                id: `USR-${Date.now()}`,
                recessCode,
                email,
                passwordHash: this._hashPassword(password),
                userType: userType || 'CORP',
                tier: tier !== undefined ? tier : 1,
                role: tier === 0 ? 'L0-3' : tier === 1 ? 'L1.1' : 'L2.5',
                companyName: companyName || null,
                realName: realName || null,
                displayName: displayName || realName || companyName || null,
                status: 'active',
                createdAt: new Date().toISOString()
            };

            users.push(newUser);
            localStorage.setItem(SessionManager.STORAGE_KEYS.USERS, JSON.stringify(users));

            return { success: true, user: newUser, recessCode };
        },

        logout() {
            SessionManager.logout();
        },

        isLoggedIn() {
            return SessionManager.isLoggedIn();
        },

        getSession() {
            return SessionManager.getSession();
        }
    };

    // ==========================================
    // 전역 등록
    // ==========================================
    window.SessionManager = SessionManager;
    window.AuthManager = AuthManager;

    // AuthManager 초기화
    AuthManager.init();

    // 페이지 자동 초기화
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => SessionManager.initPage());
    } else {
        SessionManager.initPage();
    }

    console.log('[AuthBundle] 로드 완료 v1.2.0');

})(window);
