/**
 * RECESS IMS - RoleManager v1.0
 * 역할 기반 권한 관리
 */
(function(window) {
    'use strict';

    const RoleManager = {
        version: '1.0.0',

        ROLES: {
            'L0-0': { name: '의장', tier: 0, level: 'executive' },
            'L0-1': { name: '간사', tier: 0, level: 'secretary' },
            'L0-3': { name: 'CP', tier: 0, level: 'investor' },
            'L1': { name: '컨펌자', tier: 1, level: 'confirmer' },
            'L1.1': { name: 'PD', tier: 1, level: 'producer' },
            'L1.2': { name: '데스크', tier: 1, level: 'desk' },
            'L1.3': { name: 'PM', tier: 1, level: 'manager' },
            'L1.4': { name: '팀장', tier: 1, level: 'teamlead' },
            'L1.5': { name: '팀원', tier: 1, level: 'member' },
            'L2.1': { name: 'PD', tier: 2, level: 'producer' },
            'L2.2': { name: '데스크', tier: 2, level: 'desk' },
            'L2.3': { name: 'PM', tier: 2, level: 'manager' },
            'L2.4': { name: '팀장', tier: 2, level: 'teamlead' },
            'L2.5': { name: '작업자', tier: 2, level: 'worker' }
        },

        getCurrentRole() {
            const saved = localStorage.getItem('recess_current_user');
            if (saved) {
                try {
                    const data = JSON.parse(saved);
                    return data.roleId || data.role || 'L1';
                } catch { return 'L1'; }
            }
            return 'L1';
        },

        getRoleInfo(roleId) {
            return this.ROLES[roleId] || { name: '알 수 없음', tier: 1, level: 'unknown' };
        },

        hasPermission(roleId, requiredLevel) {
            const role = this.ROLES[roleId];
            if (!role) return false;
            const levels = ['worker', 'member', 'teamlead', 'manager', 'desk', 'producer', 'confirmer', 'secretary', 'executive', 'investor'];
            return levels.indexOf(role.level) >= levels.indexOf(requiredLevel);
        },

        canApprove(roleId) {
            return ['L0-0', 'L0-1', 'L1', 'L1.1', 'L1.2'].includes(roleId);
        },

        canEdit(roleId) {
            return ['L1', 'L1.1', 'L1.2', 'L1.3', 'L2.1', 'L2.2', 'L2.3'].includes(roleId);
        }
    };

    window.RoleManager = RoleManager;
    console.log('[RoleManager] 로드 완료 v1.0.0');
})(window);
