/**
 * ============================================
 * RECESS IMS Data Manager
 * ============================================
 * 
 * 더미 데이터 연결을 위한 유틸리티 모듈
 * 
 * 사용법:
 * -------
 * <script src="./data/data-manager.js"></script>
 * <script>
 *   // 초기화
 *   await DataManager.init();
 *   
 *   // 데이터 사용
 *   const projects = DataManager.projects;
 *   const activeProjects = DataManager.getProjectsByStatus('progress');
 * </script>
 * 
 * 또는 모듈로 사용:
 * ----------------
 * import DataManager from './data/data-manager.js';
 * await DataManager.init();
 * 
 * API 전환 시:
 * -----------
 * DataManager.setBaseUrl('https://api.recess-ims.com/v1');
 * DataManager.setMode('api'); // 'local' 또는 'api'
 */

const DataManager = {
    // ==========================================
    // 설정
    // ==========================================
    config: {
        mode: 'local',  // 'local' (JSON 파일) 또는 'api' (실제 API)
        baseUrl: './data',
        apiUrl: 'https://api.recess-ims.com/v1',
        cacheEnabled: true,
        cacheDuration: 5 * 60 * 1000  // 5분
    },

    // ==========================================
    // 캐시 저장소
    // ==========================================
    cache: {
        projects: null,
        episodes: null,
        cuts: null,
        partners: null,
        personnel: null,
        estimates: null,
        orders: null,
        processes: null,
        lastFetch: {}
    },

    // ==========================================
    // 데이터 접근자 (초기화 후 사용)
    // ==========================================
    get projects() { return this.cache.projects || []; },
    get episodes() { return this.cache.episodes || []; },
    get cuts() { return this.cache.cuts || []; },
    get partners() { return this.cache.partners || []; },
    get personnel() { return this.cache.personnel || []; },
    get estimates() { return this.cache.estimates || []; },
    get orders() { return this.cache.orders || []; },
    get processes() { return this.cache.processes || []; },

    // ==========================================
    // 초기화
    // ==========================================
    async init() {
        console.log('[DataManager] 초기화 시작...');
        
        try {
            await Promise.all([
                this.load('projects'),
                this.load('episodes'),
                this.load('cuts'),
                this.load('partners'),
                this.load('personnel'),
                this.load('estimates'),
                this.load('orders'),
                this.load('processes')
            ]);
            
            console.log('[DataManager] 초기화 완료');
            console.log(`  - 프로젝트: ${this.projects.length}개`);
            console.log(`  - 에피소드: ${this.episodes.length}개`);
            console.log(`  - 컷: ${this.cuts.length}개`);
            console.log(`  - 협력사: ${this.partners.length}개`);
            console.log(`  - 인력: ${this.personnel.length}개`);
            console.log(`  - 견적서: ${this.estimates.length}개`);
            console.log(`  - 발주서: ${this.orders.length}개`);
            console.log(`  - 공정: ${this.processes.length}개`);
            
            return true;
        } catch (error) {
            console.error('[DataManager] 초기화 실패:', error);
            return false;
        }
    },

    // ==========================================
    // 데이터 로드
    // ==========================================
    async load(type) {
        // 캐시 확인
        if (this.config.cacheEnabled && this.cache[type]) {
            const lastFetch = this.cache.lastFetch[type] || 0;
            if (Date.now() - lastFetch < this.config.cacheDuration) {
                return this.cache[type];
            }
        }

        // URL 결정
        const url = this.config.mode === 'local'
            ? `${this.config.baseUrl}/${type}.json`
            : `${this.config.apiUrl}/${type}`;

        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const data = await response.json();
            
            // JSON 파일 구조에서 실제 데이터 추출
            this.cache[type] = data[type] || data;
            this.cache.lastFetch[type] = Date.now();
            
            return this.cache[type];
        } catch (error) {
            console.error(`[DataManager] ${type} 로드 실패:`, error);
            throw error;
        }
    },

    // ==========================================
    // 설정 변경
    // ==========================================
    setMode(mode) {
        this.config.mode = mode;
        this.clearCache();
    },

    setBaseUrl(url) {
        this.config.baseUrl = url;
    },

    setApiUrl(url) {
        this.config.apiUrl = url;
    },

    clearCache() {
        Object.keys(this.cache).forEach(key => {
            if (key !== 'lastFetch') this.cache[key] = null;
        });
        this.cache.lastFetch = {};
    },

    // ==========================================
    // 프로젝트 관련 헬퍼
    // ==========================================
    getProject(id) {
        return this.projects.find(p => p.id === id);
    },

    getProjectsByStatus(status) {
        return this.projects.filter(p => p.status === status);
    },

    getProjectsByPM(pmName) {
        return this.projects.filter(p => p.pm === pmName);
    },

    getActiveProjects() {
        return this.projects.filter(p => 
            p.status === 'progress' || p.status === 'urgent'
        );
    },

    getProjectStats() {
        const total = this.projects.length;
        const progress = this.projects.filter(p => p.status === 'progress').length;
        const complete = this.projects.filter(p => p.status === 'complete').length;
        const urgent = this.projects.filter(p => p.status === 'urgent').length;
        const pending = this.projects.filter(p => p.status === 'pending').length;
        
        return { total, progress, complete, urgent, pending };
    },

    // ==========================================
    // 에피소드 관련 헬퍼
    // ==========================================
    getEpisode(id) {
        return this.episodes.find(e => e.id === id);
    },

    getEpisodesByProject(projectId) {
        return this.episodes.filter(e => e.projectId === projectId);
    },

    getEpisodeProgress(projectId) {
        const eps = this.getEpisodesByProject(projectId);
        const total = eps.length;
        const complete = eps.filter(e => e.status === 'complete').length;
        return { total, complete, progress: total > 0 ? (complete / total * 100).toFixed(1) : 0 };
    },

    // ==========================================
    // 컷 관련 헬퍼
    // ==========================================
    getCut(id) {
        return this.cuts.find(c => c.id === id);
    },

    getCutsByEpisode(episodeId) {
        return this.cuts.filter(c => c.episodeId === episodeId);
    },

    getCutsByStatus(status) {
        return this.cuts.filter(c => c.status === status);
    },

    getCutsByWorker(workerId) {
        return this.cuts.filter(c => c.workerId === workerId);
    },

    getCutStats(episodeId) {
        const cuts = episodeId 
            ? this.getCutsByEpisode(episodeId) 
            : this.cuts;
        
        return {
            total: cuts.length,
            not_ordered: cuts.filter(c => c.status === 'not_ordered').length,
            ordered: cuts.filter(c => c.status === 'ordered').length,
            in_progress: cuts.filter(c => c.status === 'in_progress').length,
            review: cuts.filter(c => c.status === 'review').length,
            retake: cuts.filter(c => c.status === 'retake').length,
            approved: cuts.filter(c => c.status === 'approved').length
        };
    },

    // ==========================================
    // 협력사 관련 헬퍼
    // ==========================================
    getPartner(id) {
        return this.partners.find(p => p.id === id);
    },

    getPartnerByCode(code) {
        return this.partners.find(p => p.code === code);
    },

    getPartnersByType(type) {
        return this.partners.filter(p => p.type === type);
    },

    getPartnersByRole(role) {
        return this.partners.filter(p => p.role === role);
    },

    // ==========================================
    // 인력 관련 헬퍼
    // ==========================================
    getPerson(id) {
        return this.personnel.find(p => p.id === id);
    },

    getPersonnelByPartner(partnerId) {
        return this.personnel.filter(p => p.partnerId === partnerId);
    },

    getPersonnelByRole(role) {
        return this.personnel.filter(p => p.role === role);
    },

    getAvailableWorkers(role) {
        return this.personnel.filter(p => 
            p.role === role && p.availability !== 'unavailable' && p.status === 'active'
        );
    },

    // ==========================================
    // 견적서 관련 헬퍼
    // ==========================================
    getEstimate(id) {
        return this.estimates.find(e => e.id === id);
    },

    getEstimatesByProject(projectId) {
        return this.estimates.filter(e => e.projectId === projectId);
    },

    getEstimatesByStatus(status) {
        return this.estimates.filter(e => e.status === status);
    },

    // ==========================================
    // 발주서 관련 헬퍼
    // ==========================================
    getOrder(id) {
        return this.orders.find(o => o.id === id);
    },

    getOrdersByProject(projectId) {
        return this.orders.filter(o => o.projectId === projectId);
    },

    getOrdersByStatus(status) {
        return this.orders.filter(o => o.status === status);
    },

    getOrdersByWorker(workerId) {
        return this.orders.filter(o => o.workerId === workerId);
    },

    getPendingOrders() {
        return this.orders.filter(o => 
            o.status === 'in_progress' || o.status === 'approved'
        );
    },

    // ==========================================
    // 공정 관련 헬퍼
    // ==========================================
    getProcess(id) {
        return this.processes.find(p => p.id === id);
    },

    getProcessByCode(code) {
        return this.processes.find(p => p.code === code);
    },

    getProcessesByCategory(category) {
        return this.processes.filter(p => p.category === category);
    },

    getProcessPrice(code, difficulty = 'B') {
        const process = this.getProcessByCode(code);
        if (!process) return 0;
        const multiplier = process.difficulty[difficulty] || 1.0;
        return process.basePrice * multiplier;
    },

    // ==========================================
    // 복합 쿼리
    // ==========================================
    getProjectWithDetails(projectId) {
        const project = this.getProject(projectId);
        if (!project) return null;

        return {
            ...project,
            episodes: this.getEpisodesByProject(projectId),
            estimates: this.getEstimatesByProject(projectId),
            orders: this.getOrdersByProject(projectId)
        };
    },

    getEpisodeWithCuts(episodeId) {
        const episode = this.getEpisode(episodeId);
        if (!episode) return null;

        return {
            ...episode,
            cuts: this.getCutsByEpisode(episodeId),
            stats: this.getCutStats(episodeId)
        };
    },

    getWorkerWorkload(workerId) {
        const person = this.getPerson(workerId);
        if (!person) return null;

        const activeCuts = this.getCutsByWorker(workerId)
            .filter(c => c.status !== 'approved');
        const activeOrders = this.getOrdersByWorker(workerId)
            .filter(o => o.status === 'in_progress');

        return {
            ...person,
            activeCuts,
            activeOrders,
            cutCount: activeCuts.length,
            orderCount: activeOrders.length
        };
    }
};

// 모듈 내보내기 (ES6 모듈 환경용)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataManager;
}

// 전역 객체로도 사용 가능
if (typeof window !== 'undefined') {
    window.DataManager = DataManager;
}
